q1 answers the first question #19 in Page 216

q2 answers the second question
(combined question (#17 in Page 181-182 combined with) #5 in Page 217

q3 answers the third question #8 page 217-218

