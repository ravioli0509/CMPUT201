#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "lcs.h"

void LTS(char tand[], int len);
void EnterForLTS();
void EnterForLTSOutput();
void LTSOutputResult(char tand[], int len);
void LCTS(char tand[], int len);
void LCTSForOutput(char tand[], int len);

//includes all the prototypes for LTS.c




