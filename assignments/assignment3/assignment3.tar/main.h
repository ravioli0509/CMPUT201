#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <time.h>

#include "lcs.h"
#include "lps.h"
#include "lts.h"
#include "utility.h"


char *file;
char *input;

#define N 10000

//includes all the prototypes for main.c