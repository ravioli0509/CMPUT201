#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "lcs.h"

int LTS(char tand[], int len);

void EnterSequenceForLTS();

void EnterSequenceForLTSOutput();

int LTSOutputResult(char tand[], int len);

void ReadInputLTS();

//includes all the prototypes for LTS.c




