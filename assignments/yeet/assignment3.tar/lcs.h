#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

int FindMaxFromTable(int a, int b);

void LCS(char s1[], char s2[], int m, int n, int cond);

void EnterSequenceForLCS();

int returnLCSLength(char s1[], char s2[], int m, int n);

void EnterSequenceForLCPS();

void EnterSequenceForLPSOutput();

void EnterSequenceForLCTS();

void EnterSequenceForLPSOutput();

void EnterSequenceForLCSOutput();

void EnterSequenceForLTSOutput();

void EnterSequenceForLCPSOutput();

void EnterSequenceForLCTSOutput();

// includes all the prototypes for LCS.c
