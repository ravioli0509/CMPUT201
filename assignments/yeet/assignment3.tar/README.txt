ccid : nawalage 
collaboraters: none
reference: on cover

note: some functions are not done
Used the LCPS and LCTS algorithm from Hazel's class since my section is A3
