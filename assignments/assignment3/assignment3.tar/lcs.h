#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

int FindMaxFromTable(int a, int b);
void LCS(char s1[], char s2[], int m, int n, int cond);
void EnterForLCS();
int returnLCSLength(char s1[], char s2[], int m, int n);
void EnterForLCPS();
void EnterForLPSOutput();
void EnterForLCTS();
void EnterForLPSOutput();
void EnterForLCSOutput();
void EnterForLTSOutput();
void EnterForLCPSOutput();
void EnterForLCTSOutput();
// includes all the prototypes for LCS.c
