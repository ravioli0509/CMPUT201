#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

int give_random();
int generatesequence();
int generatesequenceandfile(char *fileName);


// includes give random integer function 
// generate sequence and duplicate but other outputs to file